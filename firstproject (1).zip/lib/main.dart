import 'dart:ui';
import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(primaryColor: Colors.blue),
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text("Login Page"),
          centerTitle: true,
          backgroundColor: Colors.greenAccent[400],
        ),
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: NetworkImage('https://en.pimg.jp/055/319/907/1/55319907.jpg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Center(
            child: Column(children: [
              SizedBox(
                height: 40,
              ),
              Container(
                  width: 300,
                  child: TextField(
                    decoration: InputDecoration(labelText: 'Email', border: OutlineInputBorder()),
                  )),
              SizedBox(
                height: 40,
              ),
              Container(
                  width: 300,
                  child: TextField(
                    decoration: InputDecoration(labelText: 'Password', border: OutlineInputBorder()),
                  )),
              SizedBox(
                height: 40,
              ),
              TextButton(
                  onPressed: () {},
                  child: Text('Login'),
                  style: TextButton.styleFrom(
                    primary: Colors.white,
                    backgroundColor: Colors.greenAccent[400],
                    onSurface: Colors.grey,
                    textStyle: TextStyle(fontSize: 30),
                  )),
            ]),
          ),
        ),
      ),
    );
  }
}
